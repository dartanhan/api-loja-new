<?php if(session($key ?? 'status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session($key ?? 'status')); ?>

    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\laravel_black\loja\resources\views/alerts/success.blade.php ENDPATH**/ ?>